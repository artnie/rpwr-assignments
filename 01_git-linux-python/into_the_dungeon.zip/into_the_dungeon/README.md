# Beware!

It's much more fun to traverse the dungeon from a bash terminal.
